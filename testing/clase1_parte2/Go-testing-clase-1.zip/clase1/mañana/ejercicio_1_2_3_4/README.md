### Ejercicio 1 

## ¿Cuáles son las diferencias entre White Box y Black Box?

```
La principal diferencia entré estos métodos radica en que los test White Box es posible conocer el diseño, implementación y estructura. Mientras que en los test Black Box esta información es desconocida para quien realiza los tests.
```

Ejercicio 2:

## ¿Qué es un test funcional?.

```
Los tests funcionales nos permiten evaluar funcionalidades o requerimientos basándose en un conjunto de entrada (casos), comprobando su correspondiente salida, y así  verificar que los resultados obtenidos son correctos.
```

Ejercicio 3:

## ¿Qué es un Test de Integración?

```
Los test de Integración nos permiten corroborar el correcto funcionamiento entre módulos o servicios, permitiendo verificar sus funcionalidades en conjunto.
```

Ejercicio 4:

## Indicar las dimensiones de calidad prioritarias en MELI.

```
  - Funcionalidad (Functinality)
  - Rendimiento (Performance)
  - Fiabilidad (Reliability)
  - Seguridad (Security)
  - Mantenibilidad (Maintainability)
```