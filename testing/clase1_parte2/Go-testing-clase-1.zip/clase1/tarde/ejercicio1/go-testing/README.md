## Instalación paquete testify

Test de la función restar utilizando testify y la libreria estandar

```go
// import 
import (
	"testing"
	"github.com/stretchr/testify/assert"
)

// testify 
go get github.com/stretchr/testify
```