package calculadora

/*
Ejercicio 1 - Test Unitario Restar
Para el método Restar() visto en la clase, realizar el test unitario correspondiente. Para esto:
    1. Dentro de la carpeta go-testing crear un archivo calculadora.go con la función a probar.
    2. Dentro de la carpeta go-testing crear un archivo calculadora_test.go con el test diseñado.
*/

func Restar(num1, num2 int64) int64 {
	return num1 - num2
}
