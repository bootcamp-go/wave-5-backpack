package paqueteuno

func PaqueteUno() string {
	return "Soy el paquete uno"
}
