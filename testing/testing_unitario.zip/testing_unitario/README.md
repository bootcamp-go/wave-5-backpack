### Testing

```go
go test ./... -v 
```